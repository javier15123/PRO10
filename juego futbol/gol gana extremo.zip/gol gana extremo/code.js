

var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["69fe73c7-300a-470f-91bc-deb7a814eb0a","3f43a4e1-bc23-4f2c-b65f-81044ccd799e","1c746abb-45c1-45a1-b4b0-11dd6b5d9f41","da6e9fe1-c631-40f1-8257-496ff5c3f756","274f3e20-bd95-4a45-8fe1-3a153ad327df","b052b98c-e547-4f02-a04b-9705af6f8b92","59803ced-4989-4feb-89a0-96faafb86783"],"propsByKey":{"69fe73c7-300a-470f-91bc-deb7a814eb0a":{"name":"B","sourceUrl":null,"frameSize":{"x":512,"y":512},"frameCount":1,"looping":true,"frameDelay":12,"version":"M0xHP1cNIOc8TiYFPQU0R._5nNUG3dE.","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":512,"y":512},"rootRelativePath":"assets/69fe73c7-300a-470f-91bc-deb7a814eb0a.png"},"3f43a4e1-bc23-4f2c-b65f-81044ccd799e":{"name":"Barca","sourceUrl":null,"frameSize":{"x":512,"y":512},"frameCount":1,"looping":true,"frameDelay":12,"version":"s29ZagnoIbWZocCo21h7eOJL308kUGEi","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":512,"y":512},"rootRelativePath":"assets/3f43a4e1-bc23-4f2c-b65f-81044ccd799e.png"},"1c746abb-45c1-45a1-b4b0-11dd6b5d9f41":{"name":"P","sourceUrl":"assets/v3/animations/tKNGi6KQv3fJG6Nv59cH58jH-QIZLWpLIX5DHYID-Ik/1c746abb-45c1-45a1-b4b0-11dd6b5d9f41.png","frameSize":{"x":512,"y":512},"frameCount":1,"looping":true,"frameDelay":4,"version":"GiMgZwawQykVvJsl2z74p5DSdO9eap3P","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":512,"y":512},"rootRelativePath":"assets/v3/animations/tKNGi6KQv3fJG6Nv59cH58jH-QIZLWpLIX5DHYID-Ik/1c746abb-45c1-45a1-b4b0-11dd6b5d9f41.png"},"da6e9fe1-c631-40f1-8257-496ff5c3f756":{"name":"M","sourceUrl":"assets/v3/animations/tKNGi6KQv3fJG6Nv59cH58jH-QIZLWpLIX5DHYID-Ik/da6e9fe1-c631-40f1-8257-496ff5c3f756.png","frameSize":{"x":512,"y":512},"frameCount":1,"looping":true,"frameDelay":4,"version":"GC6vap.5eKlm8aa5HwPyAqackP9nAfmN","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":512,"y":512},"rootRelativePath":"assets/v3/animations/tKNGi6KQv3fJG6Nv59cH58jH-QIZLWpLIX5DHYID-Ik/da6e9fe1-c631-40f1-8257-496ff5c3f756.png"},"274f3e20-bd95-4a45-8fe1-3a153ad327df":{"name":"_copy_1","sourceUrl":null,"frameSize":{"x":512,"y":512},"frameCount":1,"looping":true,"frameDelay":12,"version":"UDO4VUpVqJJykqMsGNpRSRuuEbG2xC7H","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":512,"y":512},"rootRelativePath":"assets/274f3e20-bd95-4a45-8fe1-3a153ad327df.png"},"b052b98c-e547-4f02-a04b-9705af6f8b92":{"name":"Madrid","sourceUrl":null,"frameSize":{"x":512,"y":512},"frameCount":1,"looping":true,"frameDelay":12,"version":"OCsgxCt67EhxRVsKL50aAGEef30rGPd9","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":512,"y":512},"rootRelativePath":"assets/b052b98c-e547-4f02-a04b-9705af6f8b92.png"},"59803ced-4989-4feb-89a0-96faafb86783":{"name":"b","sourceUrl":null,"frameSize":{"x":626,"y":402},"frameCount":1,"looping":true,"frameDelay":12,"version":"RqzF7DUo8V2grzf_8cmMMgYFnnUIrsRt","categories":[""],"loadedFromSource":true,"saved":true,"sourceSize":{"x":626,"y":402},"rootRelativePath":"assets/59803ced-4989-4feb-89a0-96faafb86783.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var b = createSprite(200,200);
 b.setAnimation("b");
var delantero1 = createSprite(200, 100,20,20);
delantero1.shapeColor="blue";
delantero1.setAnimation("B");
delantero1.scale=0.12
var delantero2 = createSprite(200, 300,20,20);
delantero2.shapeColor="blue";
delantero2.setAnimation("M");
delantero2.scale=0.12
var ball = createSprite(200, 200,12,12);
ball.shapeColor="black";
ball.setAnimation("P")
ball.scale=0.05;
var porteria1 = createSprite(200, 388,130,20);
porteria1.shapeColor="yellow";

var porteria2 = createSprite(200, 12,130,20);
porteria2.shapeColor="red";

var gameState  ="serve";
 
 var pared1 = createSprite(55,0,30,1000);
pared1.shapeColor="white";

var pared2 = createSprite(345,0,30,1000);
pared2.shapeColor="white";

var pared3 = createSprite(300,0,100,30);
pared3.shapeColor="white";

var pared4 = createSprite(100,0,100,30);
pared4.shapeColor="white";

var pared5 = createSprite(100,400,100,30);
pared5.shapeColor="white";

var pared6 = createSprite(300,400,100,30);
pared6.shapeColor="white";

var pared7 = createSprite(200,0,100,5);
pared7.shapeColor="white";

var pared8 = createSprite(200,400,100,5);
pared8.shapeColor="white";

var pared9=createSprite(255,17,25,50)
pared9.shapeColor="white"

var pared10=createSprite(144,17,25,50)
pared10.shapeColor="white"

var pared11=createSprite(260,375,25,50)
pared11.shapeColor="white"
var pared12=createSprite(140,375,25,50)
pared12.shapeColor="white"





for(var i = 50;i < 400; i=i+30){

  var Madrid =createSprite(20,i ,20,20)
  Madrid.setAnimation("Madrid")
  Madrid.scale=0.1
}

for(var i = 50; i < 400; i=i+30){

  var Barca=createSprite(380,i,20,20);
  Barca.setAnimation("Barca");
  Barca.scale=0.1;
}
var playerScore=0;
var player2Score=0;

function draw() {
background("green");
if(gameState=="serve"){
//Texto de bienvenida
   textSize(13);
  fill("blue");
  text("Bienvenido, presiona Enter para comenzar",72,180);
  

  
 //Asignamos velocidad a la pelota 
  if(keyDown("enter")){
    ball.velocityX=8;
    ball.velocityY=10;
    gameState="play";
  
}
}
  
  
  
  if(gameState=="play"){
    if(ball.isTouching(porteria1)||ball.isTouching(porteria2)){
  playSound("assets/category_sports/Crowd_Cheer_SFX.mp3", false);
playSound("assets/category_sports/Goal-Long_SFX.mp3", false);
 gameState="end";
    }
  }
    
    
  if(gameState=="end"){
  ball.velocityX=0;
  ball.velocityY=0;


fill("black");
  textSize(20);
  text("fin del juego😁💀",110,180);
}
fill("skyblue")
textSize(12)
text("poderes",85,24)
text("P I O",85,44)
text("poderes",85,360)
text("Z X C",85,380)



createEdgeSprites();
ball.bounceOff(rightEdge);
ball.bounceOff(leftEdge);
ball.bounceOff(topEdge);
ball.bounceOff(bottomEdge);


//movimientos de los delanteros 
//delantero1

if(keyDown(RIGHT_ARROW)){
delantero1.x=delantero1.x+5;
}

if(keyDown(UP_ARROW)){
delantero1.y=delantero1.y-5;
}

if(keyDown(DOWN_ARROW)){
  delantero1.y=delantero1.y +5;
}
if(keyDown(LEFT_ARROW)){
delantero1.x=delantero1.x-5;
}

 
//delantero2 
 

if(keyDown("w")){
delantero2.y=delantero2.y -5;
}

if(keyDown("s")){
  delantero2.y=delantero2.y +5;
}

if(keyDown("a")){
delantero2.x=delantero2.x -5;
}

if(keyDown("d")){
delantero2.x=delantero2.x +5;
}
//PODERES
if(keyDown("p")){
delantero1.scale=0.18;
}
if(keyDown("o")){
delantero1.scale=0.12;  
}
if(keyDown("i")){
if(keyDown(RIGHT_ARROW)){
delantero1.x=delantero1.x+15;
}

if(keyDown(UP_ARROW)){
delantero1.y=delantero1.y-15;
}

if(keyDown(DOWN_ARROW)){
  delantero1.y=delantero1.y +15;
}
if(keyDown(LEFT_ARROW)){
delantero1.x=delantero1.x-15;
}
}






//DELANTERO2

if(keyDown("x")){
  delantero2.scale=0.12;
}
if(keyDown("Z")){
delantero2.scale=0.20;
}

if(keyDown("c")){

if(keyDown("w")){
delantero2.y=delantero2.y -15;
}

if(keyDown("s")){
  delantero2.y=delantero2.y +15;
}

if(keyDown("a")){
delantero2.x=delantero2.x -15;
}

if(keyDown("d")){
delantero2.x=delantero2.x +15;
}
}



createEdgeSprites();


ball.bounceOff(delantero1);
 ball.bounceOff(delantero2);
 ball.bounceOff(porteria1);
 ball.bounceOff(porteria2);
 ball.bounceOff(pared1);
  ball.bounceOff(pared2);
  ball.bounceOff(pared3);  
  ball.bounceOff(pared4);  
  ball.bounceOff(pared9);
   ball.bounceOff(pared10);
   ball.bounceOff(pared11);
   ball.bounceOff(pared12);
  
  
  delantero1.bounceOff(pared1);
  delantero1.bounceOff(pared2);
  delantero1.bounceOff(pared3);
  delantero1.bounceOff(pared4);
  delantero1.bounceOff(pared5);
  delantero1.bounceOff(pared6);
  delantero1.bounceOff(delantero2);
  delantero1.bounceOff(porteria1);
  delantero1.bounceOff(porteria2);
  delantero2.bounceOff(delantero1);

delantero2.bounceOff(pared1);
  delantero2.bounceOff(pared2);
  delantero2.bounceOff(pared3);
  delantero2.bounceOff(pared4);
  delantero2.bounceOff(pared5);
  delantero2.bounceOff(pared6);
 delantero2.bounceOff(porteria1);
  delantero2.bounceOff(porteria2);













drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
